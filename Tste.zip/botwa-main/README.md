# Termux Bot Whatsapp by Zhirrr

<p align="center">
<a href="#"><img title="BOT WHATSAPP" src="https://img.shields.io/badge/Bot Whatsapp-blue?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://github.com/Zhirrr"><img title="Author" src="https://img.shields.io/badge/Author-Zhirrr-orange.svg?style=for-the-badge&logo=github"></a>
</p>
<p align="center">
<a href="https://github.com/Zhirrr/followers"><img title="Followers" src="https://img.shields.io/github/followers/Zhirrr?color=red&style=flat-square"></a>
<a href="https://github.com/Zhirrr/botwa/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/Zhirrr/botwa?color=blue&style=flat-square"></a>
<a href="https://github.com/Zhirrr/botwa/network/members"><img title="Forks" src="https://img.shields.io/github/forks/Zhirrr/botwa?color=red&style=flat-square"></a>
<a href="https://github.com/Zhirrr/botwa/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/Zhirrr/botwa?label=Watchers&color=blue&style=flat-square"></a>
</p>
<p align='center'>
   <a href="https://wa.me/6283898698875"><img height="30" src="https://c.top4top.io/p_1837yybbf0.jpeg"></a>&nbsp;&nbsp;
   <a href="https://instagram.com/zhirr_ajalah"><img height="30" src="https://raw.githubusercontent.com/TobyG74/TobyG74/main/instagram.jpg"></a>
</P>
</P>

## Information

#### This script is open to anyone! If you want to add commands, please contribute / pull request! Buying and selling scripts is prohibited!
- Change [ownerNumber](https://github.com/Zhirrr/botwa/blob/main/index.js#L221) in index.js to be your number
ownerNumber = "6283898698875@s.whatsapp.net"
- Change [BotInfo](https://github.com/Zhirrr/botwa/blob/main/index.js#L29) in index.js to be your bot name
- Change [Donasi](https://github.com/Zhirrr/botwa/blob/main/lib/donasi.js) in /lib/donasi.js to be your number

## Contact

If you find some bugs please contact the WhatsApp number on Contact

- [WHATSAPP](https://wa.me/6283898698875)

### Install
Clone this project

```bash
> pkg install git
> git clone https://github.com/Zhirrr/botwa
> cd botwa
```

Install the dependencies:

```bash
> pkg install bash
> bash install.sh
```

### Usage
run the Whatsapp bot

```bash
> node index.js
```
after running it you need to scan the qr

## 🙏 Big Special Thanks To

* [`Mhankbarbar`](https://github.com/MhankBarBar)
* [`ArugaZ`](https://github.com/ArugaZ) 
